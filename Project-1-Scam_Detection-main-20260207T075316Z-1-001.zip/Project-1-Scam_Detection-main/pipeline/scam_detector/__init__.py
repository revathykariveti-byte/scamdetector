# # pipeline/scam_detector/__init__.py

# from .detector import ScamDetector

# __all__ = ['ScamDetector'] 